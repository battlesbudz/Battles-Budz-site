// Barrel export for all schema modules - maintains backward compatibility
export * from "./core";
export * from "./ecommerce";
export * from "./forum";
export * from "./investor";
export * from "./gamification";
export * from "./events";
export * from "./documents";