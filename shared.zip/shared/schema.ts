// Legacy barrel export for backward compatibility
// All schemas are now organized in domain-specific modules under ./schemas/
export * from "./schemas";
